from torchvision.models.convnext import ConvNeXt,CNBlock,LayerNorm2d,CNBlockConfig  
import torch
import torch.nn as nn

class convnext_s(ConvNeXt):
    def __init__(self,
                block_setting = [
                                    CNBlockConfig(96, 192, 3),
                                    CNBlockConfig(192, 384, 3),
                                    CNBlockConfig(384, 768, 27),
                                    CNBlockConfig(768, None, 3),
                                ],
                stochastic_depth_prob = 0.4,
                num_classes=1000,
                block = CNBlock,
                ):
        super(convnext_s, self).__init__(block_setting=block_setting,
                                        stochastic_depth_prob=stochastic_depth_prob,
                                        num_classes=num_classes,
                                        block = block
                                        )
        self.feature_size = 768
        

    def forward(self, x, return_feature=False, return_feature_list=False):
        x = self.features(x)
        # Cannot use "squeeze" as batch-size can be 1
        x = self.avgpool(x)
        feature = x
        x = self.classifier(x)

        if return_feature:
            return x, feature
        elif return_feature_list:
            return x, [feature]
        else:
            return x
        
    def get_fc(self):
        fc = self.classifier[2]
        return fc.weight.cpu().detach().numpy(), fc.bias.cpu().detach().numpy()

    def get_fc_layer(self):
        return self.classifier[2]
    

if __name__ == "__main__":
    net = convnext_s()
    print(net)
    from torchvision.models import ConvNeXt_Small_Weights
    from torch.hub import load_state_dict_from_url
    weights = ConvNeXt_Small_Weights.IMAGENET1K_V1
    net.load_state_dict(load_state_dict_from_url(weights.url))
    print('load v1')

    # weights = ConvNeXt_Small_Weights.IMAGENET1K_V2
    # net.load_state_dict(load_state_dict_from_url(weights.url))
    # print('load v2')
    