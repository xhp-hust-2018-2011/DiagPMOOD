from torchvision.models.mobilenetv2 import MobileNetV2,InvertedResidual
import torch
import torch.nn as nn

class mobilenetv2(MobileNetV2):
    def __init__(self,
                num_classes=1000,
                width_mult=1.0,
                inverted_residual_setting = [
                # t, c, n, s
                [1, 16, 1, 1],
                [6, 24, 2, 2],
                [6, 32, 3, 2],
                [6, 64, 4, 2],
                [6, 96, 3, 1],
                [6, 160, 3, 2],
                [6, 320, 1, 1],
            ],
            round_nearest =8,
            block = InvertedResidual,
            norm_layer = nn.BatchNorm2d,
            dropout=0.2):
        super(mobilenetv2, self).__init__(num_classes=num_classes,
                                        width_mult=width_mult,
                                        inverted_residual_setting=inverted_residual_setting,
                                        round_nearest = round_nearest,
                                        block = block,
                                        norm_layer = norm_layer,
                                        dropout = dropout
                                        )
        self.feature_size = 1280
        

    def forward(self, x, return_feature=False, return_feature_list=False):
        x = self.features(x)
        # Cannot use "squeeze" as batch-size can be 1
        x = nn.functional.adaptive_avg_pool2d(x, (1, 1))
        x = torch.flatten(x, 1)
        feature = x
        x = self.classifier(x)

        if return_feature:
            return x, feature
        elif return_feature_list:
            return x, [feature]
        else:
            return x
        
    def get_fc(self):
        fc = self.classifier[1]
        return fc.weight.cpu().detach().numpy(), fc.bias.cpu().detach().numpy()

    def get_fc_layer(self):
        return self.classifier[1]
    

if __name__ == "__main__":
    net = mobilenetv2()
    print(net)
    from torchvision.models import MobileNet_V2_Weights
    from torch.hub import load_state_dict_from_url
    weights = MobileNet_V2_Weights.IMAGENET1K_V1
    net.load_state_dict(load_state_dict_from_url(weights.url))
    print('load v1')

    weights = MobileNet_V2_Weights.IMAGENET1K_V2
    net.load_state_dict(load_state_dict_from_url(weights.url))
    print('load v2')
    