from torchvision.models.shufflenetv2 import ShuffleNetV2,InvertedResidual
import torch
import torch.nn as nn


class shufflenetv2_x1_5(ShuffleNetV2):
    def __init__(self,
                stages_repeats=[4, 8, 4],
                stages_out_channels=[24, 176, 352, 704, 1024],
                num_classes=1000,
                inverted_residual=InvertedResidual):
        super(shufflenetv2_x1_5, self).__init__(
                stages_repeats=stages_repeats,
                stages_out_channels=stages_out_channels,
                num_classes=num_classes,
                inverted_residual=inverted_residual)
        self.feature_size = 1024
        

    def forward(self, x, return_feature=False, return_feature_list=False):
        x = self.conv1(x)
        x = self.maxpool(x)
        x = self.stage2(x)
        x = self.stage3(x)
        x = self.stage4(x)
        x = self.conv5(x)
        x = x.mean([2, 3])  # globalpool
        feature = x
        x = self.fc(x)

        if return_feature:
            return x, feature
        elif return_feature_list:
            return x, [feature]
        else:
            return x
        
    def get_fc(self):
        fc = self.fc
        return fc.weight.cpu().detach().numpy(), fc.bias.cpu().detach().numpy()

    def get_fc_layer(self):
        return self.fc
    

if __name__ == "__main__":
    net = shufflenetv2_x1_5()
    print(net)
    from torchvision.models import ShuffleNet_V2_X1_5_Weights
    from torch.hub import load_state_dict_from_url
    weights = ShuffleNet_V2_X1_5_Weights.IMAGENET1K_V1
    net.load_state_dict(load_state_dict_from_url(weights.url))
    print('load v1')

    # weights = MobileNet_V2_Weights.IMAGENET1K_V2
    # net.load_state_dict(load_state_dict_from_url(weights.url))
    # print('load v2')
    