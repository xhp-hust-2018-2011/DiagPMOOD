from torchvision.models.swin_transformer import SwinTransformer
import torch

class Swin_T(SwinTransformer):
    def __init__(self,
                 patch_size=[4, 4],
                 embed_dim=96,
                 depths=[2, 2, 6, 2],
                 num_heads=[3, 6, 12, 24],
                 window_size=[7, 7],
                 stochastic_depth_prob=0.2,
                 num_classes=1000):
        super(Swin_T,
              self).__init__(patch_size=patch_size,
                             embed_dim=embed_dim,
                             depths=depths,
                             num_heads=num_heads,
                             window_size=window_size,
                             stochastic_depth_prob=stochastic_depth_prob,
                             num_classes=num_classes)
        self.feature_size = embed_dim * 2**(len(depths) - 1)
        self.flatten_2 = torch.flatten


    def pixel_forward(self, x, return_feature=False):
        x = self.features(x)
        # print(x.size()) # torch.Size([200, 7, 7, 768])
        x = self.norm(x)
        try:
            x = self.permute(x)
        except:
            x = torch.permute(x,(0,3,1,2))
        
        pixel_feature = x
        x = self.avgpool(x)
        x = self.flatten_2(x, start_dim=1)

        B,C,H,W = pixel_feature.size()
        pixel_feature = pixel_feature.permute([0,2,3,1]).view(B,H*W,C)
        pixel_logits_cls = self.head(pixel_feature)


        if return_feature:
            return_dict =  {'avg_feature':x, 
                    'pixel_feature':pixel_feature,
                    'pixel_logit_cls':pixel_logits_cls,
                    }
            return self.head(x), return_dict
        else:
            return self.head(x)

    def forward(self, x, return_feature=False):
        x = self.features(x)
        # print(x.size()) # torch.Size([200, 7, 7, 768])
        x = self.norm(x)
        try:
            x = self.permute(x)
        except:
            x = torch.permute(x,(0,3,1,2))
        x = self.avgpool(x)
        x = self.flatten_2(x, start_dim=1)

        if return_feature:
            return self.head(x), x
        else:
            return self.head(x)

    def forward_threshold(self, x, threshold):
        x = self.features(x)
        x = self.norm(x)
        try:
            x = self.permute(x)
        except:
            x = torch.permute(x,(0,3,1,2))
        x = self.avgpool(x)
        x = self.flatten_2(x, start_dim=1)
        feature = x.clip(max=threshold)
        feature = feature.view(feature.size(0), -1)
        logits_cls = self.head(feature)

        return logits_cls

    def get_fc(self):
        fc = self.head
        return fc.weight.cpu().detach().numpy(), fc.bias.cpu().detach().numpy()

    def get_fc_layer(self):
        return self.head
