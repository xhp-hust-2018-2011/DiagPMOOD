import torch.nn as nn


class weaknet(nn.Module):
    def __init__(self, backbone,config):
        super(weaknet, self).__init__()
        self.backbone = backbone
        # freeze the backbone weights
        # if config.freeze_backbone:
        #    for name, param in self.backbone.named_parameters():
        #        param.requires_grad = False 
        # also initilize the fcnet
        fc_layer = self.backbone.get_fc_layer()
        in_ch,out_ch = fc_layer.in_features,fc_layer.out_features
        self.fcnet = nn.Linear(in_ch,out_ch)

    def forward_train(self,x):
        logit_cls_old, feature = self.backbone(x, return_feature=True)
        logit_cls = self.fcnet(feature)
        return_dict = {'logit_cls_old':logit_cls_old,
                       'logit_cls':logit_cls,}
        return return_dict

    def pixel_forward_train(self,x):
        logit_cls_old, return_dict_old = self.backbone.pixel_forward(x, return_feature=True)
        logit_cls = self.fcnet(return_dict_old['avg_feature'])
        pixel_logit_cls = self.fcnet(return_dict_old['pixel_feature'])

        return_dict = {'logit_cls_old':logit_cls_old,
                       'logit_cls':logit_cls,
                       'pixel_logit_cls_old':return_dict_old['pixel_logit_cls'],
                       'pixel_logit_cls':pixel_logit_cls,
                       'pixel_feature':return_dict_old['pixel_feature'],
                       'avg_feature':return_dict_old['avg_feature']}
        return return_dict

    # this is for testing, actually no need to return the feature list
    def forward(self, x, return_feature=False, return_feature_list=False):
        logit_cls_old, feature = self.backbone(x, return_feature=True)
        del logit_cls_old
        logit_cls = self.fcnet(feature)
        if return_feature:
            return logit_cls, feature
        else:
            return logit_cls

    def get_fc(self):
        fc = self.fcnet
        return fc.weight.cpu().detach().numpy(), fc.bias.cpu().detach().numpy()
