import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

import openood.utils.comm as comm
from openood.utils import Config

from .lr_scheduler import cosine_annealing


class WeakTrainer:
    def __init__(self, net: nn.Module, train_loader: DataLoader,
                 config: Config) -> None:

        self.net = net
        self.train_loader = train_loader
        self.config = config

        # can freeze the parameter of features here
        # add a parm "config.optimizer.trained_params=['all','fc']"
        if config.optimizer.trained_params=='all':
            pass
        elif config.optimizer.trained_params=='fc':
            for name, param in net.backbone.named_parameters():
                param.requires_grad = False  
            # Check which parameters are frozen
            for name, param in net.backbone.named_parameters():
                if param.requires_grad:
                    print(f"{name} is {'' if param.requires_grad else 'not '}trainable")
            # aslo freeze bn and batchnorm without updating
            for module in net.backbone.modules():
                if isinstance(module, nn.Dropout):
                    module.eval()  # Disable dropout by setting it to eval mode
                if isinstance(module, nn.BatchNorm2d):
                    module.eval()  # Freeze BatchNorm layers by setting them to eval mode    

        trainable_params = filter(lambda p: p.requires_grad, net.parameters())
        self.optimizer = torch.optim.SGD(
            trainable_params,
            config.optimizer.lr,
            momentum=config.optimizer.momentum,
            weight_decay=config.optimizer.weight_decay,
            nesterov=True,
        )

        self.scheduler = torch.optim.lr_scheduler.LambdaLR(
            self.optimizer,
            lr_lambda=lambda step: cosine_annealing(
                step,
                config.optimizer.num_epochs * len(train_loader),
                1,
                1e-6 / config.optimizer.lr,
            ),
        )

    def train_epoch(self, epoch_idx):
        self.net.train()
        # get the network if use distribution training
        if self.config.num_gpus>1:
            tmp_net = self.net.module
        else:
            tmp_net = self.net


        loss_avg = 0.0
        train_dataiter = iter(self.train_loader)
        

        for train_step in tqdm(range(1,
                                     len(train_dataiter) + 1),
                               desc='Epoch {:03d}: '.format(epoch_idx),
                               position=0,
                               leave=True,
                               disable=not comm.is_main_process()):
            # if train_step>10:
            #     continue
            batch = next(train_dataiter)
            data = batch['data'].cuda()
            target = batch['label'].cuda()

            # forward
            # logits_classifier = self.net(data)
            pred_dict = tmp_net.forward_train(data)
            # get the correct prediction
            old_predcls = pred_dict['logit_cls_old'].max(dim=1)[1]
            right_mask = (old_predcls == target)

            logits_classifier = pred_dict['logit_cls']

            loss = F.cross_entropy(logits_classifier[right_mask], target[right_mask])

            # backward
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            self.scheduler.step()

            # exponential moving average, show smooth values
            with torch.no_grad():
                loss_avg = loss_avg * 0.8 + float(loss) * 0.2

        # comm.synchronize()

        metrics = {}
        metrics['epoch_idx'] = epoch_idx
        metrics['loss'] = self.save_metrics(loss_avg)

        return self.net, metrics

    def save_metrics(self, loss_avg):
        all_loss = comm.gather(loss_avg)
        total_losses_reduced = np.mean([x for x in all_loss])

        return total_losses_reduced
